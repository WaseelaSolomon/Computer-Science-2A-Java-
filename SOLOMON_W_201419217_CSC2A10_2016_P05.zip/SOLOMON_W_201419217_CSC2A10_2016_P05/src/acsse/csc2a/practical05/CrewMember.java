package acsse.csc2a.practical05;

/**
 * This class is for the CrewMember object
 */

public abstract class CrewMember 
{
	private final String	ID;
	private String			rank;
	private String			surname;
	private String			type;
	private String			special;
	private String 			level;

	/**
	 * 
	 * constructor
	 * initialises CrewMember class variables
	 */
	public CrewMember(String ID, String rank, String surname, String type, String special, String level)
	{
		//using the parameters to set the class variables
		this.ID = ID;
		this.rank = rank;
		this.surname = surname;
		this.type = type;
		this.special = special;
		this.level = level;
	}
	
	/**
	 * 
	 * function to get the rank variable
	 * @return: returns rank
	 */
	public String getRank()
	{
		return rank;
	}
	
	/**
	 * 
	 * function to set/modify the rank variable
	 */
	public void setRank(String rank)
	{
		this.rank = rank;
	}

	/**
	 * 
	 * function to get the surname variable
	 * @return: returns surname
	 */
	public String getSurname()
	{
		return surname;
	}
	
	/**
	 * 
	 * function to set/modify the surname variable
	 */
	public void setSurname(String surname)
	{
		this.surname = surname;
	}

	/**
	 * 
	 * function to get the type variable
	 * @return: returns type
	 */
	public String getType()
	{
		return type;
	}

	/**
	 * 
	 * function to set/modify the type variable
	 */
	public void setType(String type)
	{
		this.type = type;
	}

	/**
	 * 
	 * function to get the special variable
	 * @return: returns special
	 */
	public String getSpecial()
	{
		return special;
	}

	/**
	 * 
	 * function to set/modify the special variable
	 */
	public void setSpecial(String special)
	{
		this.special = special;
	}
	
	/**
	 * 
	 * function to get the ID variable
	 * @return: returns ID
	 */
	public String getID()
	{
		return ID;
	}
	
	/**
	 * 
	 * function to get the level variable
	 * @return: returns level
	 */
	public String getlevel()
	{
		return level;
	}

	/**
	 * 
	 * function to set/modify the level variable
	 */
	public void setlevel(String level)
	{
		this.level = level;
	}
	
	/**
	 * 
	 * function to be implemented in subclasses
	 */
	public abstract void interact();
	
	/**
	 * 
	 * function to override the toString method to return textual representation of object
	 */
	@Override
	public String toString()
	{
		//return each variable as a single string 
		return "ID: " + ID + " RANK: " + rank + " SURNAME: " + surname + " TYPE: " + type + " SPECIAL: " + special + " LEVEL: " + level;
	}
	
}

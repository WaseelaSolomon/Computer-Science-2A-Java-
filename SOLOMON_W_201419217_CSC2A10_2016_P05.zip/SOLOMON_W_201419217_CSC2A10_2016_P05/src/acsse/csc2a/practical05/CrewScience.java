package acsse.csc2a.practical05;
import acsse.csc2a.practical05.CrewMember;

/**
 * This class is for the CrewScience object
 */

public class CrewScience extends CrewMember
{
private String value;

	/**
	 * 
	 * constructor
	 * initialises CrewScience class variables
	 */
	public CrewScience(String ID, String rank, String surname, String type, String special, String level, String value) {
		super(ID, rank, surname, type, special, level); //invoke superclass constructor
		this.value = value;
	}

	/**
	 * 
	 * function to get the value variable
	 * @return: returns value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * 
	 * function to set/modify the value variable
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * 
	 * function to override the interact method inherited from superclass CrewMember
	 */
	@Override
	public void interact() 
	{
		//print specialised text and unique value
		System.out.println("This is a Scientist Crew Member.");
		System.out.println("Value: " + value);
	}	
	
	/**
	 * 
	 * function to override the toString method inherited from superclass CrewMember
	 */
	@Override
	public String toString()
	{
		return super.toString() + " Value: " + value;	//invoke superclass method
	}
}

package  acsse.csc2a.practical05;
import acsse.csc2a.practical05.CrewMember;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class is for the CrewRoster object
 */

public class CrewRoster 
{
	
	/**
	 * 
	 * @param rosterFileName: is the name of the file used to read data from
	 * @return: returns an array of CrewMember instances
	 */
	public static CrewMember[] readRoster(String rosterFileName)
	{
		CrewMember[] members = null;
		File roster = new File(rosterFileName);
		if (!roster.exists()) System.exit(-1);
		System.out.println("Checking file: " + rosterFileName);
		Scanner scRoster = null;
		try
		{
			scRoster = new Scanner(roster);
			String rosterLine = "";
			Pattern crewPattern = Pattern.compile("\\w{6}\\s[a-zA-Z]{3}\\s\\w+\\s\\d+\\s[A-Z]+\\s\\w+\\s([0-9]+|[a-z]+)");	//pattern to check 
			Matcher crewMatcher = null;
			int index = 0;
			if (!scRoster.hasNext()) System.exit(-1);
			members = new CrewMember[1];
			while (scRoster.hasNext())
			{
				rosterLine = scRoster.nextLine();
				crewMatcher = crewPattern.matcher(rosterLine);
				if (crewMatcher.matches())
				{
					if (index >= members.length)
					{
						System.out.println(
								"Resize " + members.length + " -> " + (members.length * 2));
						CrewMember[] tempArray = new CrewMember[members.length * 2];
						System.arraycopy(members, 0, tempArray, 0, members.length);
						members = tempArray;
					}
					StringTokenizer memberTokens = new StringTokenizer(rosterLine);
					String ID = memberTokens.nextToken();
					String rank = memberTokens.nextToken();
					String surname = memberTokens.nextToken();
					String level = memberTokens.nextToken();	//new level variable
					String type = memberTokens.nextToken();
					String special = memberTokens.nextToken();
					String value = memberTokens.nextToken();	//new value variable
					
					//check for which type a member is
					if(type.equals("COMBAT"))
					{
						members[index++] = new CrewCombat(ID, rank, surname, level, type, special, value);	//instantiate a CrewCombat object
					}
					
					if(type.equals("MEDICAL"))
					{
						members[index++] = new CrewMedic(ID, rank, surname, level, type, special, value);	//instantiate a CrewMedic object
					}
					
					if(type.equals("ENGINEERING"))
					{
						members[index++] = new CrewEngineer(ID, rank, surname, level, type, special, value);	//instantiate a CrewEngineer object
					}
					
					if(type.equals("SCIENCE"))
					{
						members[index++] = new CrewScience(ID, rank, surname, level, type, special, value);	//instantiate a CrewScience object
					}
					
					if(type.equals("PSYCHIC"))
					{
						members[index++] = new CrewPsychic(ID, rank, surname, level, type, special, value);	//instantiate a CrewPsychic object
					}
				}
				else
				{
					System.err.println(rosterLine);
				}
			}
		}
		catch (FileNotFoundException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if (scRoster != null) scRoster.close();
		}

		return members;
	}
}

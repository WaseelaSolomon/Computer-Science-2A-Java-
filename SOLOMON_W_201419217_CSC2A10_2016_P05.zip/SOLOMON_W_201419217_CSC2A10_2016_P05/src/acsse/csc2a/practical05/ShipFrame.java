//imports
package acsse.csc2a.practical05;
import acsse.csc2a.practical05.CrewMember;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.JOptionPane;

/**
 * This the the ShipFrame class that will create a GUI 
 */
public class ShipFrame extends JFrame 
{
	//variables
	private JFrame S_Frame;			//variable for the frame
	private JButton open_button;	//variable for the open button
	private JButton save_button; 	//variable for the save button
	private JPanel panel;  			//variable for the panel
	private JTextArea text_area;	//variable for the text area
	
	/**
	 * This is the constructor for the ShipFrame Class
	 */
	public ShipFrame()
	{
		Init_GUI();	//initial and set up the GUI
		Init_Panel();	//intialise and set up the panel
		Init_Buttons();	//initialise and set up the buttons
	}
	
	/**
	 * This is the function to create and initialise the state of the GUI
	 */
	public void Init_GUI()
	{
		S_Frame = new JFrame("Crew_Info");	//instantiate the variable for the GUI frame
		text_area = new JTextArea();		//instantiate the variable for the text area
		panel = new JPanel(new BorderLayout());	//instantiate the variable for the panel of the GUI
		open_button = new JButton("Open");	//instantiate the variable for open button
		save_button = new JButton("Save");	//instantiate the variable for save button
		
		S_Frame.setSize(800,800);	//set the size of the GUI frame
		S_Frame.setDefaultCloseOperation(EXIT_ON_CLOSE);	//set when the frame closes
		S_Frame.setLayout(new BorderLayout());	//set the layout of the frame
	}
	
	/**
	 * This is the function to setup the panel for the GUI
	 */
	public void Init_Panel()
	{
		//set where each part of GUI is located on GUI frame
		panel.add(open_button, BorderLayout.NORTH);
		panel.add(save_button, BorderLayout.SOUTH);
		panel.add(text_area, BorderLayout.CENTER);
		
		S_Frame.add(panel);	//add panel changes to the frame
		S_Frame.setVisible(true);	//show the frame
	}
	
	/**
	 * This is the function to create and initialise the buttons for the GUI
	 */
	public void Init_Buttons()
	{
		//setting listeners for each button click
		open_button.addActionListener(new ButtonClickListener());
		save_button.addActionListener(new SaveClickListener());
	}
	
	/**
	 * This is the class to handle the events of the open button
	 */
	class ButtonClickListener implements ActionListener
	{
		/**
		 * This is the function to Initialise and create the dialog for the text area
		 */
		public void Init_Dialog()
		{
			JFileChooser F_Chooser = new JFileChooser();	//instantiate the variable for file chooser
			F_Chooser.showOpenDialog(null);				
			File file = F_Chooser.getSelectedFile(); 	//choose a specific file using the GUI
			String FileName = file.getAbsolutePath(); 	//get the specific file's path
		
		
			CrewMember[] members = CrewRoster.readRoster(FileName);	//instantiate the variables of the crewmember class and call
																	//the readRoster function
			
			//loop through each crew member from file and display contents in the GUI text area
			for (CrewMember member : members)
			{
				text_area.append(member.toString() + " " + "\n"); 
			}
		}
		
		/**
		 * This function overrides the actionPerformed function to allow the GUI open a file in the GUI
		 */
		@Override
		public void actionPerformed(ActionEvent args0) 
		{
			Init_Dialog();	
		}
	}
	
	/**
	 * This is the class to handle the events of the save button
	 */
	class SaveClickListener implements ActionListener
	{
		/**
		 * This is the function to save a file using the GUI
		 */
		public void Init_Save()
		{
			try
			{
				BufferedWriter writer = new BufferedWriter(new FileWriter("crew_file.txt")) ;	//writing to a new file
				text_area.write(writer);
			}
			catch(IOException ex)			
			{
				ex.printStackTrace();
			}
		}
		
		/**
		 * This function overrides the actionPerformed function to allow the GUI to save on button click
		 */
		@Override
		public void actionPerformed(ActionEvent args0) 
		{
			Init_Save();
		}
	}
}
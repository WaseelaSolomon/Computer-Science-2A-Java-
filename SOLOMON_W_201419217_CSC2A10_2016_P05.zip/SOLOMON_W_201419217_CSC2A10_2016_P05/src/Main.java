import acsse.csc2a.practical05.CrewMember;	//importing packages
import acsse.csc2a.practical05.CrewRoster;
import acsse.csc2a.practical05.ShipFrame;

/**
 * This is the main class that executes code from all other classes
 */

public class Main 
{
	public static void main(String[] args)
	{
		
		CrewMember[] members = CrewRoster.readRoster("data/roster100.txt");
		for (CrewMember member : members)
		{
			System.out.println(member);
		}
		System.out.println("Valid members: "+members.length);
		ShipFrame SF = new ShipFrame();
	}
}

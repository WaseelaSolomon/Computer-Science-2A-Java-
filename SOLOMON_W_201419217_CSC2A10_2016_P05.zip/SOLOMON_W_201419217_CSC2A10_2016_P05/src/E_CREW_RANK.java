
/**
 * This is the enum for the crew member rank
 */
public enum E_CREW_RANK 
{
	ADM,
	CPT,
	CDR, 
	FLT,
	SLT,
	ENS
}

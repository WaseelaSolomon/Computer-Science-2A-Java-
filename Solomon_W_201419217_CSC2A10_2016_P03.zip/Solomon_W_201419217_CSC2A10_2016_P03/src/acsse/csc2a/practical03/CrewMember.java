package acsse.csc2a.practical03;
/**
 * 
 * @author Waseela Solomon
 *
 */

/**
 * This class is for the CrewMember object
 */

public class CrewMember 
{
	//class attributes
	public String CREW_ID;
	public String CREW_RANK;
	public String CREW_SURNAME;
	public String CREW_TYPE;
	public String CREW_SPECIAL;	
}

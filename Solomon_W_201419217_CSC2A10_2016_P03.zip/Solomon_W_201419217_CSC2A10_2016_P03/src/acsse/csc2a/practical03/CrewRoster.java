package acsse.csc2a.practical03;
import acsse.csc2a.practical03.CrewMember;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
//import java.util.StringTokenizer;
import java.util.regex.Pattern;

/**
 * 
 * @author Waseela Solomon
 *
 */

/**
 * This class is for the CrewRoster object
 */

public class CrewRoster 
{
	/**
	 * 
	 * @param FileName: is the name of the file used to read data from
	 * @return: returns an array of CrewMember instances
	 */
	public int getnumlines(File FileName)
	{
		int numlines = 0;
		Scanner txtin = null;
		
		try
		{
			txtin = new Scanner(FileName);
			while(txtin.hasNext())	//go through file while there is still another line to read
			{
				txtin.nextLine();	//go to the next line
				numlines++;		//increment the number of lines
			}
		} catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			if(txtin != null) txtin.close();	//close the file
		}
		return numlines;	
	}
	
	public CrewMember[] readRoster(String FileName)
	{
		File txtFile = new File(FileName);
		Scanner txtin = null;
		CrewMember[] CM = null; 	//array of CrewMembers for returning
		//int count = 0;
		try
		{
			int intsize = getnumlines(txtFile);		//get the number of lines for the file
			txtin = new Scanner(txtFile);
			CM = new CrewMember[intsize];
			
			//pattern to check for valid line of text in file
			Pattern Pat = Pattern.compile("\\w{6}\\s[A-Z]{3}\\s[a-zA-Z]+\\s[A-Z]+\\s[a-z]+");
			
			while(txtin.hasNext())	//go through file
			{
				String Line = txtin.nextLine();
				
				/*StringTokenizer token = new StringTokenizer(Line);
				
				CM[count].CREW_ID = token.nextToken();
				CM[count].CREW_RANK = token.nextToken();
				CM[count].CREW_SURNAME = token.nextToken();
				CM[count].CREW_TYPE = token.nextToken();
				CM[count].CREW_SPECIAL = token.nextToken();
				count++;*/
				
				if(!Pat.matcher(Line).matches())	//check if the pattern does not match
				{
					System.err.println(Line + "   DOES NOT MATCH!");	//put line in error stream
				}else
					System.out.println(Line + "   IS A MATCH!");	//output line
			}
		}
		catch(FileNotFoundException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if(txtin != null) txtin.close();	//close the file
		}
		return CM;	//return the array of CrewMember objects
	}
}

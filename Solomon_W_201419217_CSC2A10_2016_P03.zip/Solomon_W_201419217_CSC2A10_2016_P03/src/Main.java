import acsse.csc2a.practical03.CrewMember;
import acsse.csc2a.practical03.CrewRoster;

import java.io.File;

/**
 * 
 * @author Waseela Solomon
 *
 */

/**
 * This is the main class that executes code from all other classes
 */

public class Main 
{
	public static void main(String[] args) 
	{
		CrewRoster CR = new CrewRoster();	//instance of CrewRoster 
		File txtfile = new File("data/roster050.txt");
		int numlines = CR.getnumlines(txtfile);	//getting the number of lines from the file
		CrewMember[] CM = new CrewMember[numlines];	//instances of CrewMember
		CM = CR.readRoster("data/roster050.txt");	//calling readRoster method which will read from
												//file and print member details
	}
}

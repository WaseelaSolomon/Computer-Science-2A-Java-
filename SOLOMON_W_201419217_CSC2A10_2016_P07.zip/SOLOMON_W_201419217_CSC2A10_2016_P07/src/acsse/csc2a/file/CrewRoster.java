package acsse.csc2a.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;

import acsse.csc2a.model.CrewCombat;
import acsse.csc2a.model.CrewEngineer;
import acsse.csc2a.model.CrewMedic;
import acsse.csc2a.model.CrewMember;
import acsse.csc2a.model.CrewPsychic;
import acsse.csc2a.model.CrewScience;
import acsse.csc2a.model.E_CREW_RANK;
import acsse.csc2a.model.E_TILE_TYPE;
import acsse.csc2a.model.ShipLayout;
import acsse.csc2a.model.CrewEntity;

/**
 * CrewRoster Class 
 */
public class CrewRoster
{
	/**
	 * function to populate and return an array list of CrewEntity variables
	 * @param FileName is the filename for the location file
	 * @param members is an arraylist for the entity population
	 * @return an arraylist of CrewEntity instances 
	 */
	public static ArrayList<CrewEntity> readLocations(String FileName, ArrayList<CrewMember> members)
	{
		//variable to store the entities to be returned
		ArrayList<CrewEntity> entities = new ArrayList<CrewEntity>();
		
		//variable to read from data file
		DataInputStream in = null;
		try 
		{
			in = new DataInputStream(new FileInputStream(FileName));
			
			//pattern and matcher used to check the ID for each CrewMember
			Pattern crewPattern = Pattern.compile("[A-Z]{3}\\d{3}");
			Matcher crewMatcher = null;
			//variables to store the ID, row and col from the data file
			String ID = " ";
			int row;
			int col;
			//variable to keep track of the current entity
			int index = 0;
			
			 while(in.available() > 0) 
			{	 
				 //read the file data into variables
				 ID = in.readUTF();
				 row = in.readInt();
				 col = in.readInt();
				 //check if ID matches
				 crewMatcher = crewPattern.matcher(ID);
				 CrewMember tempmem = null;
				 if(crewMatcher.matches())
				 {
					 //populate the entity array list with the correct CrewMembers
					 tempmem = members.get(index);
					 CrewEntity entity = new CrewEntity(tempmem, row, col);
					 entities.add(entity);
				 }
				 index++;
	   	 	}
		}
		catch (EOFException eof)
		{
			eof.printStackTrace();
		}
		catch (IOException exio) 
		{
			exio.printStackTrace();
		}
		finally
		{
			if(in != null)
			{
				 try
				 { 
					 in.close(); 
				 }
				 catch(IOException ex)
				 {
					 ex.printStackTrace();
				 }
			}
		}
		return entities;
	}
	
	public static ShipLayout readShipLayout(String layoutFileName)
	{
		ShipLayout layout = null;
		File layoutFile = new File(layoutFileName);
		if (!layoutFile.exists()) return layout;
		System.out.println("Checking file: " + layoutFileName);
		Scanner scLayout = null;
		try
		{
			scLayout = new Scanner(layoutFile);
			String layoutLine = "";
			if (!scLayout.hasNext()) { return layout; }
			layoutLine = scLayout.nextLine();
			StringTokenizer firstLine = new StringTokenizer(layoutLine);
			int rows = Integer.parseInt(firstLine.nextToken());
			int cols = Integer.parseInt(firstLine.nextToken());
			E_TILE_TYPE[][] tiles = new E_TILE_TYPE[rows][cols];
			int row=0;
			while (scLayout.hasNext())
			{
				layoutLine = scLayout.nextLine();
				for (int col = 0; col < layoutLine.length(); col++)
				{
					tiles[row][col]=E_TILE_TYPE.getTileFromChar(layoutLine.charAt(col)); 
				}
				row++;
			}
			layout=new ShipLayout(tiles);
		}
		catch (FileNotFoundException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if (scLayout != null) scLayout.close();
		}

		return layout;
	}

	public static ArrayList<CrewMember> readRoster(String rosterFileName)
	{
		ArrayList<CrewMember> members = new ArrayList<CrewMember>();
		File roster = new File(rosterFileName);
		if (!roster.exists()) return members;
		System.out.println("Checking file: " + rosterFileName);
		Scanner scRoster = null;
		try
		{
			scRoster = new Scanner(roster);
			String rosterLine = "";
			// \w{6}\s[a-zA-Z]{3}\s\w+\s\d+\s[A-Z]+\s\w+\s\w+
			Pattern crewPattern =
					Pattern.compile("\\w{6}\\s[a-zA-Z]{3}\\s\\w+\\s\\d+\\s[A-Z]+\\s\\w+\\s\\w+");
			Matcher crewMatcher = null;
			int index = 0;
			if (!scRoster.hasNext()) { return members; }
			while (scRoster.hasNext())
			{
				rosterLine = scRoster.nextLine();
				crewMatcher = crewPattern.matcher(rosterLine);
				if (crewMatcher.matches())
				{
					StringTokenizer memberTokens = new StringTokenizer(rosterLine);
					String ID = memberTokens.nextToken();
					E_CREW_RANK rank = E_CREW_RANK.valueOf(memberTokens.nextToken());
					String surname = memberTokens.nextToken();
					int level = Integer.parseInt(memberTokens.nextToken());
					String type = memberTokens.nextToken();
					String special = memberTokens.nextToken();
					String value = memberTokens.nextToken();
					CrewMember member = null;
					switch (type)
					{
					case "SCIENCE":
					{
						member = new CrewScience(ID, rank, surname, type, special, level, value);
						break;
					}
					case "MEDICAL":
					{
						int heal = Integer.parseInt(value);
						member = new CrewMedic(ID, rank, surname, type, special, level, heal);
						break;
					}
					case "PSYCHIC":
					{
						member = new CrewPsychic(ID, rank, surname, type, special, level, value);
						break;
					}
					case "ENGINEERING":
					{

						int repair = Integer.parseInt(value);
						member = new CrewEngineer(ID, rank, surname, type, special, level, repair);
						break;
					}
					case "COMBAT":
					{
						int damage = Integer.parseInt(value);
						member = new CrewCombat(ID, rank, surname, type, special, level, damage);
						break;
					}
					default:
						break;
					}
					members.add(member);
				}
				else
				{
					System.err.println(rosterLine);
				}
			}
		}
		catch (FileNotFoundException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if (scRoster != null) scRoster.close();
		}

		return members;
	}
}
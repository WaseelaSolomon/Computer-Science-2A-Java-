package acsse.csc2a.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;

import acsse.csc2a.model.E_TILE_TYPE;
import acsse.csc2a.model.ShipLayout;
import acsse.csc2a.model.CrewEntity;
import acsse.csc2a.model.CrewMember;
import acsse.csc2a.file.CrewRoster;

public class ShipPanel extends JPanel
{
	private ShipLayout	layout;
	private static int	tileSize	= 50;
	private static int	x, y, hts = tileSize / 2, qts = hts / 2;

	public ShipPanel(ShipLayout layout)
	{
		this.layout = layout;
		Dimension d = new Dimension(layout.getRows() * tileSize, layout.getColumns() * tileSize);
		this.setSize(d);
		this.setPreferredSize(d);
	}
	
	/**
	 * function used to paint the components of the panel
	 * used to paint the CrewEntity array from file to specific locations
	 */
	@Override
	protected void paintComponent(Graphics g)
	{
		//variable to store an arraylist of crewentities
		ArrayList<CrewEntity> entities = CrewRoster.readLocations("data/locations025.dat", CrewRoster.readRoster("data/roster025.txt"));
		super.paintComponent(g);
		g.clearRect(0, 0, getWidth(), getHeight());
		for (int r = 0; r < layout.getRows(); r++)
		{
			for (int c = 0; c < layout.getColumns(); c++)
			{
				// Flipping rows and columns to display the same as the contents of the file
				E_TILE_TYPE tile = layout.getTile(c, r);
				x = r * tileSize;
				y = c * tileSize;
				switch (tile)
				{
					case EMPTY:
					{
						g.setColor(Color.GRAY);
						g.fillRect(x, y, tileSize, tileSize);
					}
						break;
					case H_WALL:
					{
						g.setColor(Color.GRAY);
						g.fillRect(x, y, tileSize, tileSize);
						g.setColor(Color.BLACK);
						g.fillRect(x, y + qts, tileSize, hts);
					}
						break;
					case V_WALL:
					{
						g.setColor(Color.GRAY);
						g.fillRect(x, y, tileSize, tileSize);
						g.setColor(Color.BLACK);
						g.fillRect(x + qts, y, hts, tileSize);
					}
						break;
					case DOOR:
					{
						g.setColor(Color.BLUE);
						g.fillRect(x, y, tileSize, tileSize);
					}
						break;
					default:
					{
						g.setColor(new Color(r * 10 + 50, c * 10 + 50, 255));
						g.fillRect(x, y, tileSize, tileSize);
					}
				}
				// Draw tile outline
				g.setColor(Color.BLACK);
				g.drawRect(x, y, tileSize, tileSize);
				
			}
		}
		
		//for each loop to go through arraylist and paint each entity
		for(CrewEntity e : entities)
		{
			CrewMember tempmem = e.getMember();	//variable to store a crewmember from entity array
			
			//loops to go through the layout
			for (int r = 0; r < layout.getRows(); r++)
			{
				for (int c = 0; c < layout.getColumns(); c++)
				{
					x = r * tileSize;
					y = c * tileSize;
					//check if current location is a crewentity  
					if((r == e.getRow()) & (c == e.getCol()))
					{
						//paint each entity based on crewmember type
						switch(tempmem.getType())
						{
							case "COMBAT":
							{
								g.setColor(Color.YELLOW);
								g.fillOval(x, y, tileSize, tileSize);
								break;
							}
							case "ENGINEER":
							{
								g.setColor(Color.RED);
								g.fillOval(x, y, tileSize, tileSize);
								break;
							}
							case "MEDICAL":
							{
								g.setColor(Color.PINK);
								g.fillOval(x, y, tileSize, tileSize);
								break;
							}
							case "PSYCHIC":
							{
								g.setColor(Color.GREEN);
								g.fillOval(x, y, tileSize, tileSize);
								break;
							}
							case "SCIENCE":
							{
								g.setColor(Color.ORANGE);
								g.fillOval(x, y, tileSize, tileSize);
								break;
							}
							default:
								break;
						}
					}
				}
			}
		}
	}
}

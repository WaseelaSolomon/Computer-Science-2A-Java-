package acsse.csc2a.model;

import acsse.csc2a.model.CrewMember;

/**
 * the CrewEntity Class that will store different crewmembers and their locations
 *
 */
public class CrewEntity 
{
	//class variables 
	private CrewMember member;
	private int row;
	private int col;
	
	//constructor
	/**
	 * constructor for the CrewEntity class 
	 * @param member for setting the crewmember variable
	 * @param row for setting the row location
	 * @param col for setting the column location
	 */
	public CrewEntity(CrewMember member, int row, int col) 
	{
		this.member = member;
		this.row = row;
		this.col = col;
	}

	/**
	 * get a specific member variable
	 * @return crewmember instance
	 */
	public CrewMember getMember() {
		return member;
	}

	/**
	 * get a row variable
	 * @return row variable
	 */
	public int getRow() {
		return row;
	}

	/**
	 * set the variable for rows
	 *@param row variable for row
	 */
	public void setRow(int row) {
		this.row = row;
	}

	/**
	 * get a column variable
	 * @return column variable
	 */
	public int getCol() {
		return col;
	}

	/**
	 * set the variable for columns
	 *@param col variable for columns
	 */
	public void setCol(int col) {
		this.col = col;
	}
	
}

package acsse.csc2a.model;

/**
 * @author Mr A. Maganlal
 */
public enum E_TILE_TYPE
{
	EMPTY('_'),
	H_WALL('-'),
	V_WALL('|'),
	DOOR('=');

	private final char symbol;

	private E_TILE_TYPE(char sym)
	{
		symbol = sym;
	}

	public static E_TILE_TYPE getTileFromChar(final char sym)
	{
		for (E_TILE_TYPE tile : values())
		{
			if (tile.symbol == sym) return tile;
		}
		return EMPTY;
	}
}

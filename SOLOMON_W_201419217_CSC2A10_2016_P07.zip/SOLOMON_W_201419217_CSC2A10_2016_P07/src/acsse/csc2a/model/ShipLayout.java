package acsse.csc2a.model;

/**
 * @author Mr A. Maganlal
 */
public class ShipLayout
{
	private E_TILE_TYPE[][] tiles;

	public ShipLayout(E_TILE_TYPE[][] tiles)
	{
		this.tiles = tiles;
	}

	public E_TILE_TYPE getTile(int row, int col)
	{
		return tiles[row][col];
	}

	public int getRows()
	{
		return tiles.length;
	}
	
	public int getColumns()
	{
		return tiles[0].length;
	}
}

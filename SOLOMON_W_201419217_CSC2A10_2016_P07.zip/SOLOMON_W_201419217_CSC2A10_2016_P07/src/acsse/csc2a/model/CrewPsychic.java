package acsse.csc2a.model;

/**
 * @author Mr A. Maganlal
 */
public class CrewPsychic extends CrewMember
{
	private String influence;

	public CrewPsychic(String iD, E_CREW_RANK rank, String surname, String type, String special,
			int level, String influence)
	{
		super(iD, rank, surname, type, special, level);
		this.influence = influence;
	}

	@Override
	public String toString()
	{
		return String.format("%s\t%s", super.toString(), influence);
	}

	@Override
	public void interact()
	{
		System.out.format("Influence: %s%n", influence);
	}

	public String getInfluence()
	{
		return influence;
	}

	public void setInfluence(String influence)
	{
		this.influence = influence;
	}

}

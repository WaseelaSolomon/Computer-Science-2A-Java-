package acsse.csc2a.model;

/**
 * @author Mr A. Maganlal
 */
public class CrewScience extends CrewMember
{
	private String enchancement;

	public CrewScience(String iD, E_CREW_RANK rank, String surname, String type, String special,
			int level, String enchancement)
	{
		super(iD, rank, surname, type, special, level);
		this.enchancement = enchancement;
	}

	@Override
	public String toString()
	{
		return String.format("%s\t%s", super.toString(), enchancement);
	}

	@Override
	public void interact()
	{
		System.out.format("Enhancement: %s%n", enchancement);
	}

	public String getEnchancement()
	{
		return enchancement;
	}

	public void setEnchancement(String enchancement)
	{
		this.enchancement = enchancement;
	}

}

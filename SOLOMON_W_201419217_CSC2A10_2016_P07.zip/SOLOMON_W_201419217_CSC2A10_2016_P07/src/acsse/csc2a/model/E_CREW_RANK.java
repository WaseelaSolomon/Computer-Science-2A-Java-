package acsse.csc2a.model;
import java.util.Random;

public enum E_CREW_RANK
{
	ADM("Admiral"), CPT("Captain"), CDR("Commander"), FLT("First Lieutenant"),
	SLT("Second Lieutenant"), ENS("Ensign");

	private String rankLongName;
	private static Random randGen = new Random(42);

	private E_CREW_RANK(String rankName)
	{
		this.rankLongName = rankName;
	}

	public static E_CREW_RANK randomRank()
	{

		return values()[randGen.nextInt(values().length)];
	}
}
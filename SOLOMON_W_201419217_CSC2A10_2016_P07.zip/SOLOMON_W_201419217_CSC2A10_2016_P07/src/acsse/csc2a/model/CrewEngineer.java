package acsse.csc2a.model;

/**
 * @author Mr A. Maganlal
 */
public class CrewEngineer extends CrewMember
{
	private int repair;

	public CrewEngineer(String iD, E_CREW_RANK rank, String surname, String type, String special,
			int level, int repair)
	{
		super(iD, rank, surname, type, special, level);
		this.repair = repair;
	}

	@Override
	public String toString()
	{

		return String.format("%s\t%d", super.toString(), repair);
	}

	@Override
	public void interact()
	{
		System.out.format("Repair dealt: %d%n", repair);
	}

	public int getRepair()
	{
		return repair;
	}

	public void setRepair(int repair)
	{
		this.repair = repair;
	}

}

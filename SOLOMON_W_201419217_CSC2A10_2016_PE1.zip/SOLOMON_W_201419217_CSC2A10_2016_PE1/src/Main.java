import acsse.csc2a.ApplicationFrame;

import java.awt.Dimension;
import javax.swing.JFrame;

public class Main 
{

	public static void main(String[] args) 
	{
		ApplicationFrame frame = new ApplicationFrame();	//instantiating the frame instance
		frame.setTitle("Cipher GUI");	//setting the title for the frame 
		
		Dimension size = new Dimension(600, 600);	//setting the dimensions for the frame
		frame.setSize(size);
		frame.setPreferredSize(size);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);	//display the frame 
	}

}

package acsse.csc2a;
import acsse.csc2a.Cipher;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;


/**
 * 
 * This is the CipherPanel class that will handle all of the necessary components
 *
 */
public class CipherPanel extends JPanel
{
	//variables
	public JTextArea plaintxt;
	public JTextArea ciphertxt;
	public JButton encrypt;
	public JButton decrypt;
	
	/**
	 * 
	 * Constructor for CipherPanel class that will create components of the frame 
	 *
	 */
	public CipherPanel()
	{
		//variables for text areas
		plaintxt = new JTextArea();
		ciphertxt = new JTextArea();
		
		//variables for buttons
		encrypt = new JButton("Encrypt");
		decrypt = new JButton("Decrypt");
		
		/**
		 * 
		 * function to handle the encrypt button click action event
		 *
		 */
		//handles encrypt button click
		encrypt.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e)
			{
				String original = plaintxt.getText();	//get the text inputted into the textarea
				String result = Cipher.transform(original);	//encrypt the text
				ciphertxt.append(result);	//display encryption in the other text area
			}
		});
		
		/**
		 * 
		 * function to handle the decrypt button click action event 
		 *
		 */
		//handles decrypt button click
		decrypt.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e)
			{
				String cipher = ciphertxt.getText();	//get the text inputted into the textarea
				String plain = Cipher.transform(cipher);	//decrypt the text
				plaintxt.append(plain);		//display decryption in the other text area
			}
		});
	}
}

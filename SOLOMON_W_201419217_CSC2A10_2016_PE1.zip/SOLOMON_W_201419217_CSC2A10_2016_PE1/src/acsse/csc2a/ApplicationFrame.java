package acsse.csc2a;
import acsse.csc2a.CipherPanel;
import acsse.csc2a.Cipher;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.Box;

/**
 * 
 * This is the ApplicationFrame class that creates the frame for the GUI
 *
 */
public class ApplicationFrame extends JFrame 
{
	//customised panel variable
	public CipherPanel CPanel;
	
	/**
	 * 
	 * Constructor for the ApplicationFrame class that will add the panel to the frame
	 *
	 */
	public ApplicationFrame()
	{
		CPanel = new CipherPanel();	//instantiation of the custom panel
		
		//placing the text areas into a box layout
		Box txts = Box.createVerticalBox();
		txts.add(CPanel.plaintxt);
		txts.add(CPanel.ciphertxt);
		
		add(txts, BorderLayout.CENTER);
		
		//placing the buttons in the frame
		add(CPanel.encrypt, BorderLayout.NORTH);
		add(CPanel.decrypt, BorderLayout.SOUTH);
	}
}

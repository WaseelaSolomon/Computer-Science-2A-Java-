package acsse.csc2a;
/**
 * @author BR Greaves
 */
public class Cipher 
{
	private static final int KEY = 12;	//The key used for "encryption/decryption"

	/**
	 * Transforms a plain text message to cipher text or cipher text message back to plain text
	 * i.e.: originalText -- transform()-- cipher text OR
	 *       originalText -- transform()-- plain text
	 * @param message accepts the message to be transformed
	 * @return The transformed text 
	 */
	public static String transform(String message)
	{
		// Convert message to a char array		
		char[] original = message.toCharArray();
		// Make an array for output
		char[] transformed = new char[original.length];
		for(int index = 0; index < original.length; index++)
		{
			transformed[index] = ((char) (original[index] ^ KEY));
		}
		return new String(transformed);
	}
}

public class UJString
{
	private int length;
	private char[] content;
	
	private final boolean isValidIndex(int index)
	{
		return ((index < length) && (index >= 0));
	}
	
	public UJString()
	{
		length = 11;
		char hw = new char["HELLO WORLD"];
		content = new char[11];
		for(int k = 0; k < 11; k++)
			content[k] = hw[k];
	}
	
	public UJString(final UJString other)
	{
		length = other.length;
		content = new char[length];
		for(int k = 0; k < length; k++)
			content[k] = other.content[k];
	}
	
	public UJString(final char[] a, int length)
	{
		length = 1;
		content = new char[length];
		for(int k = 0; k < length; k++)
			content[k] = a[k];
	}
	
	public final int getLength()
	{
		
	}
	
	public final char getAt(int index)
	{
		
	}
	
	public void setAt(int index, char newChar)
	{
		
	}
	
	public final boolean isEqual(final UJString rhs)
	{
		if(length != rhs.length)
		return false;
	
		for(int k = 0; k < length; k++)
		{
			if(content[k] != rhs.content[k])
				return false;
		}
		return true;
	}
	
	public final UJString concat(final UJString rhs)
	{
		
	}
}
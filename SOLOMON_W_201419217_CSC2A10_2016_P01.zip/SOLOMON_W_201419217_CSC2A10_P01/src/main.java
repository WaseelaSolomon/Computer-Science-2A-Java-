public class main
{
	public static void main(String[] args)
	{
		System.out.println("ENCRYPTED STRING TEST");
		EncryptedString esHello = new EncryptedString("Hello",5, 42);
		//for(int k = 0; k < esHello.getLength(); k++)
        //system.out.println("Index " + k + ": " + esHello.getAt(k));
		EncryptedString esUJ = new EncryptedString(" UJ",3, 42);
		System.out.println("COMBINING........");
		EncryptedString esHelloUJ = new EncryptedString(esHello.concat(esUJ));
		System.out.println("ENCRYPTING........");
		esHelloUJ.encrypt();
		//for(int k = 0; k < esHelloUJ.getLength(); k++)
			//system.out.println("Index " + k + ": " + esHelloUJ.getAt(k));
		esHelloUJ.encrypt();
		System.out.println("DECRYPTING........");
		//for(int k = 0; k < esHelloUJ.getLength(); k++)
			//system.out.println("Index " + k + ": " + esHelloUJ.getAt(k));
	}
}
public class EncryptedString
{
	public static final int DEFAULT_KEY = 1337;
	public static final int ERROR_CONCAT_KEY_MISMATCH = -57;
	
	public enum EDEBUG_LEVEL
	{
		NONE,
		CONS,
		ALL
	};
	
	
	private int key;
	UJString[] data;
	static final int debug = 0;
	
	public EncryptedString()
	{
		key = DEFAULT_KEY;
		if(debug > 0)
			System.out.println("Default constructor");
	}
	
	public EncryptedString(final EncryptedString other)
	{
		key = other.key;
		data = new UJString(other.data);
	}
	
	public EncryptedString(final UJString other)
	{
		key = DEFAULT_KEY;
		data = new UJString(other);
	}
	
	public EncryptedString(final String a, int length, int key)
	{
		this.key = key;
		data = new UJString(a, length);
	}

	public final int getLength()
	{
		return data.getLength();
	}

	public final char getAt(int index)
	{
		return data.getAt(index);
	}
	
	public void setAt(int index, char newChar)
	{
		data.setAt(index, newChar);
	}

	public final boolean isEqual(final EncryptedString rhs)
	{
		return data.isEqual(rhs.data) && (key == rhs.key);
	}

	public final EncryptedString concat(final EncryptedString rhs)
	{
		if(key != rhs.key)
		{
			system.out.println("Only EncryptedStrings with identical keys may be combined");
			exit(ERROR_CONCAT_KEY_MISMATCH);
		}
		UJString ujCombined = new UJString(data.concat(rhs.data));
		EncryptedString esCombined = new EncryptedString(ujCombined);
		esCombined.key = key;
		return esCombined;
	}

	public void encrypt()
	{
		for(int k = 0; k < data.getLength(); k++)
			data.setAt(k, data.getAt(k) ^ key);
	}
	
	
}
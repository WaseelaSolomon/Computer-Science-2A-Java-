package acsse.csc2a.practical02;	//putting EncryptedString class into a package
import acsse.csc2a.practical02.UJString;	//importing the UJString class from the package

/**
* @author Mr. A Maganlal
* @author Ms. W Solomon
*/

public class EncryptedString
{
	public final int	DEFAULT_KEY					= 1337;
	public final int	ERROR_CONCAT_KEY_MISMATCH	= -57;
	
	enum EDEBUG_LEVEL
	{
		NONE, CONS, ALL
	}

	private int							key;
	private UJString					data;
	private static final EDEBUG_LEVEL	debug	= EDEBUG_LEVEL.NONE;

	/**
	*no args constructor that initialises the key to the value of the default key
	*/
	public EncryptedString()
	{
		key = DEFAULT_KEY;	//sets the key to the default key
		if (debug.compareTo(EDEBUG_LEVEL.NONE) > 0)
		{
			System.out.println("Default Constructor");
		}
	}
	
	/**
	* @Param other: this variable is an instance of the EncryptedString class
	* constructor that takes an object of the EncryptedString type as a parameter to initialise the object
	*/
	public EncryptedString(EncryptedString other)
	{
		key = other.key;	//sets the key to the key given by parameter object
		data = new UJString(other.data);	//initialises data using parameter object
	}

	/**
	* @Param other: this variable is an instance of the UJString class
	* constructor that takes an object of the UJString type to initialise the data variable
	*/
	public EncryptedString(UJString other)
	{
		data = new UJString(other);	//initialises data using parameter object
	}

	/**
	* @Param a: this is an array of characters parameter
	* @Param key: this is the integer parameter that takes in a key
	* constructor that takes in a char array and an integer key to initialise the key and data variables
	*/
	public EncryptedString(char[] a, int key)
	{
		this.key = key;	
		data = new UJString(a);
	}

	/**
	*function to get the length of the data array
	* @return: returns length of data array
	*/
	public int getLength()
	{
		return data.getLength();	//returns length of the data array
	}

	/**
	* @Param index: this is to specify which element of the array to return
	*function to get a specific element in the data array
	* @return: returns an element in the data array
	*/
	public char getAt(int index)
	{
		return data.getAt(index);	//returns a specific element in array
	}

	/**
	* @Param index: this is the integer parameter for the indexing variable
	* @Param newChar: this is the char array variable to set the specific element's array of characters
	*function to set the value of a specific element in the data array
	*/
	public void setAt(int index, char newChar)
	{
		data.setAt(index, newChar);	//sets the values for specific element in array
	}

	/**
	* @Param rhs: this variable is an instance of the EncryptedString class
	*function to compare if the keys are the same
	* @return: returns true or false on condition that the keys are identical
	*/
	public boolean isEqual(EncryptedString rhs)
	{
		return (data.isEqual(rhs.data) && (key == rhs.key));	//returns true if keys match
	}

	/**
	* @Param: this variable is an instance of the EncryptedString class
	*function to combine two EncryptedStrings on condition that the keys are identical
	* @return: returns the end result of combining two strings
	*/
	public EncryptedString concat(EncryptedString rhs)
	{
		if (key != rhs.key)
		{
			System.err.println("Only EncryptedStrings with identical keys may be combined");
			System.exit(ERROR_CONCAT_KEY_MISMATCH);
		}
		UJString ujCombined = new UJString(data.concat(rhs.data));	//instantiates UJString variable
		EncryptedString esCombined = new EncryptedString(ujCombined);	//instantiates EncryptedString variable
		esCombined.key = key;	
		return esCombined;	//return the combined encrypted strings
	}

	/**
	*function to ecrypt a string of characters
	*/
	public void encrypt()
	{
		for (int k = 0; k < data.getLength(); k++)
		{
			data.setAt(k, ((char) (data.getAt(k) ^ key)));	//code to encrypt a string of characters
		}
	}
}

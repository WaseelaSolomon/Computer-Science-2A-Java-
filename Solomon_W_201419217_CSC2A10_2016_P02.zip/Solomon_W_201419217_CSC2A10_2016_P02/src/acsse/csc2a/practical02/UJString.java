package acsse.csc2a.practical02;	//putting the UJString class in the package 

/**
* @author Mr. A Maganlal
* @author Ms. W Solomon
*/

public class UJString
{
	private char[] content;	//variable to store the string to encrypt

	/**
	*no args constructor that initialises the char array to "HELLO WORLD"
	*/
	public UJString()
	{
		char[] hw =
				{ 'H', 'E', 'L', 'L', 'O', ' ', 'W', 'O', 'R', 'L', 'D' };	//initialising the string
																			//variable 
		content = hw;
	}

	/**
	* @Param other: this variable is an instance of the UJString class
	* constructor that takes an object of the EncryptedString type as a parameter to initialise the object's char array
	*/
	public UJString(UJString other)
	{
		content = other.content;	//copying the character array from the parameter variable into class variable
	}

	/**
	* @Param a: this is an array of characters parameter
	* constructor that takes in a char array to initialise the content array of characters
	*/
	public UJString(char[] a)
	{
		content = a; //copying the character array from the parameter variable into class variable
	}

	/**
	*function to get the length of the content array
	* @return: returns length of content array
	*/
	public int getLength()
	{
		return content.length;	//returning the length of the content array
	}

	/**
	* @Param index: this is to specify which element of the array to return
	*function to get a specific element in the content array
	* @return: returns an element in the content array
	*/
	public char getAt(int index)
	{
		if (!isValidIndex(index))
		{
			System.out.println("Invalid index during get: " + index);
		}
		return this.content[index];	//returning a specific element in the array
	}

	/**
	* @Param index: this is the integer parameter for the indexing variable
	* @Param newChar: this is the char array variable to set the specific element's array of characters
	*function to set the value of a specific element in the content array
	*/
	public void setAt(int index, char newChar)
	{
		if (!isValidIndex(index))
		{
			System.out.println("Invalid index during get: " + index);
		}
		this.content[index] = newChar; //setting the value of a specific element in the array
	}

	/**
	* @Param rhs: this variable is an instance of the UJString class
	*function to compare if the length and contents of two arrays are the same
	* @return: returns true or false on condition that the length and contents are identical
	*/
	public boolean isEqual(UJString rhs)
	{
		if (this.content.length != rhs.content.length) { return false; }
		for (int k = 0; k < this.content.length; k++)
		{
			if (this.content[k] != rhs.content[k]) { return false; }
		}
		return true;	//returning true if the length and contents of the arrays are identical
	}

	/**
	* @Param: this variable is an instance of the UJString class
	* function to combine two strings 
	* @return: returns the end result of combining two strings
	*/
	public UJString concat(UJString rhs)
	{
		int newLength = rhs.content.length + content.length; //setting a new length variable for combined string
		char[] c = new char[newLength];	//creating a new char array for combined string 
		for (int k = 0; k < content.length; k++)
		{
			c[k] = content[k];
		}
		for (int b = content.length; b < newLength; b++)
		{
			c[b] = rhs.content[b - content.length];
		}	//combine the two string arrays into the newly created char array
		
		char[] cp = c;
		UJString ret = new UJString(cp);
		return ret; //return the combined strings
	}

	/**
	*function to check for a valid index
	* @return: returns true or false on condition that the index is a valid value
	*/
	private boolean isValidIndex(int index)
	{
		return ((index < content.length) && index >= 0); //check if the index is valid
	}
}

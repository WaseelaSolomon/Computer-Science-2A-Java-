import acsse.csc2a.practical02.EncryptedString;

public class Main
{
	public static void main(String[] args)
	{
		int intIndex = 0;
		char charNew = ' ';

		System.out.println("ENCRYPTED STRING TEST");
		EncryptedString esHello = new EncryptedString(("Hello").toCharArray(), 42);
		for (int k = 0; k < esHello.getLength(); k++)
		{
			System.out.println("Index " + k + ": " + esHello.getAt(k));
		}
		EncryptedString esUJ = new EncryptedString((" UJ").toCharArray(), 42);
		System.out.println("COMBINING........");
		EncryptedString esHelloUJ = new EncryptedString(esHello.concat(esUJ));
		System.out.println("ENCRYPTING.......");
		esHelloUJ.encrypt();
		for (int k = 0; k < esHelloUJ.getLength(); k++)
		{
			System.out.println("Index " + k + ": " + esHelloUJ.getAt(k));
		}
		System.out.println("DECRYPTING.......");
		esHelloUJ.encrypt();
		for (int k = 0; k < esHelloUJ.getLength(); k++)
		{
			System.out.println("Index " + k + ": " + esHelloUJ.getAt(k));
		}
	}
}

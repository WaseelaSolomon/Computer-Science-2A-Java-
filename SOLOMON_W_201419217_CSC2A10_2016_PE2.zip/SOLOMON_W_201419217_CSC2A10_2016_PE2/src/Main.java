import acsse.csc2a.PracticalE2.FileReaderWriter;

import java.util.ArrayList;

/**
 * 
 * @author Solomon W
 *
 *This is the Main class that compiles and executes the code of all other classes in this project
 */
public class Main
{
	public static void main(String[] args) 
	{
		//instantiating variable of FileReaderWriter to read/write to file
		FileReaderWriter FRW = new FileReaderWriter();
		
		//array list to store names of endangered spies read from file
		ArrayList<String> spies = FRW.readFile("data/spies.txt");
		
		//displaying endangered spies' names on the console
		System.out.println("Spies That Are In Danger: " + '\n');
		for(String s : spies)
		{
			System.out.println(s);
		}
		
		System.out.println('\n' + "Writing list to file called 'Endangered Spies List' located in the project folder directory" + '\n');
		//writing the list of endangered spies' names to a file called 'Endangered Spies List' in the data directory
		FRW.WriteFile("Endangered Spies List.txt", spies); 

	}
}

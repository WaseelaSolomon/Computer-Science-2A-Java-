package acsse.csc2a.PracticalE2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * 
 * @author Solomon W
 * 
 *This is the FileReaderWriter class responsible for reading from and writing to file
 */
public class FileReaderWriter 
{
	/**
	 * This function will read the names and danger levels of spies and get the names 
	 * of the endangered spies
	 * @param FileName: for the name of the file to read from
	 * @return: an arraylist of the names of endangered spies
	 */
	public ArrayList<String> readFile(String FileName)
	{
		ArrayList<String> spies = new ArrayList<String>();	//array to store the names of spies
		File input = new File(FileName);	//the file to be read
		if(input.exists())	//checking if the file exists
		{
			Scanner sc = null;
			try
			{
				sc = new Scanner(input);
				
				//variables to store the retrieved data from file
				String name;
				int danger;
				
				//reading from file
				while(sc.hasNext())
				{
					String line = sc.nextLine();	//retrieve the next line
					
					StringTokenizer token = new StringTokenizer(line, "@");
					
					//retrieve data into respective variables
					name = token.nextToken();
					danger = Integer.parseInt(token.nextToken());
					
					if(danger > 5)
					{
						spies.add(name);	//if the spy danger is greater than 5, add spy name to arraylist
					}
				}
			}
			catch(FileNotFoundException ex)
			{
				ex.printStackTrace();
			}
			finally
			{
				if(sc!=null) sc.close();	//close the file
			}
		}
		return spies;
	}
	
	/**
	 * This is the function to write the endangered spies' names to a text file
	 * @param filename: name of the file to be created
	 * @param spies: array of the names to be written to file 
	 */
	public void WriteFile(String filename, ArrayList<String> spies)
	{
		File output = new File(filename);	//creating the new file 
		
		PrintWriter pw = null;	//PrintWriter used to write strings to new file
		
		try
		{
			pw = new PrintWriter(output);
			
			//writing to file
			pw.println("List of Spies That Are In Danger: ");
			pw.println();
			
			//go through the arraylist an write each name to file on a new line
			for(String s : spies)
			{
				pw.write(s);
				pw.println();
			}
		}
		catch(FileNotFoundException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if(pw!=null) pw.close();	//close the file
		}
	}
}

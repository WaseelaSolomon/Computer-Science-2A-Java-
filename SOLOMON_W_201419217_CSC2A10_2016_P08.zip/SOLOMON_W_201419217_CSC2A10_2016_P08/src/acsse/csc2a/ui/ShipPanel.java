package acsse.csc2a.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;
import java.util.*;
import acsse.csc2a.model.E_TILE_TYPE;
import acsse.csc2a.model.ShipLayout;
import acsse.csc2a.file.CrewRoster;
import acsse.csc2a.model.CrewEntity;

public class ShipPanel extends JPanel
{
	private ShipLayout	layout;
	private static int	tileSize	= 50;
	private ArrayList<CrewEntity> entities = null;
	private DrawGraphicsVisitor gfx = new DrawGraphicsVisitor();	//DrawGraphicsVisitor variable
	

	public ShipPanel(ShipLayout layout)
	{
		this.layout = layout;
		Dimension d = new Dimension(layout.getRows() * tileSize, layout.getColumns() * tileSize);
		this.setSize(d);
		this.setPreferredSize(d);
		
		//setting the width and height attributes of the layout class
		this.layout.setWidth(getWidth());
		this.layout.setHeight(getHeight());
	}
	
	/**
	 * function used to paint the components of the panel
	 * used to paint the CrewEntity array from file to specific locations
	 */
	@Override
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.clearRect(0, 0, getWidth(), getHeight());
		gfx.setGraphics(g);	//setting the graphics
		
		layout.accept(gfx);	//draw the layout using the accept method
		
		//check if there are entities to be drawn
		if(entities!=null)
		{
			for(CrewEntity e : entities)
			{
				e.accept(gfx);	//draw entities using the accept method
			}
		}
	}
	
	public void drawCrewEntities(ArrayList<CrewEntity> entities){
		this.entities = entities;
		repaint();
	}
}

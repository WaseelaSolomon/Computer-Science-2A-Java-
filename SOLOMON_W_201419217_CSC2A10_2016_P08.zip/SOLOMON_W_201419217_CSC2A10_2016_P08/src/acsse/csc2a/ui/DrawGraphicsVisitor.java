package acsse.csc2a.ui;

import java.awt.Color;
import java.awt.Graphics;

import acsse.csc2a.model.CrewEntity;
import acsse.csc2a.model.CrewMember;
import acsse.csc2a.model.E_TILE_TYPE;
import acsse.csc2a.model.IDrawVisitor;
import acsse.csc2a.model.ShipLayout;

/**
 * 
 * @author Solomon W
 * this is the DrawGraphicsVisitor class responsible for drawing each component
 */
public class DrawGraphicsVisitor implements IDrawVisitor 
{
	//variables
	private Graphics g;
	private static int tileSize = 50;
	private static int	x, y, hts = tileSize / 2, qts = hts / 2;
	
	/**
	 * this is the function to set the graphics variable
	 * @param g: is the graphics variable used to draw each component
	 */
	public void setGraphics(Graphics g) {
		this.g = g;
	}

	/**
	 * function to draw each crew entity onto the gui
	 * @param entity: entity to be drawn
	 */
	@Override
	public void draw(CrewEntity entity) 
	{
		if(entity!=null)
		{
			g.setColor(Color.CYAN);
			g.fillOval(entity.getRow() * tileSize, entity.getCol() * tileSize, tileSize, tileSize);
		}
	}

	/**
	 * function to draw the ship layout onto the gui
	 * @param layout: ship layout to be drawn
	 */
	@Override
	public void draw(ShipLayout layout) {
		for (int r = 0; r < layout.getRows(); r++)
		{
			for (int c = 0; c < layout.getColumns(); c++)
			{
				// Flipping rows and columns to display the same as the contents of the file
				E_TILE_TYPE tile = layout.getTile(c, r);
				x = r * tileSize;
				y = c * tileSize;
				switch (tile)
				{
					case EMPTY:
					{
						g.setColor(Color.GRAY);
						g.fillRect(x, y, tileSize, tileSize);
					}
						break;
					case H_WALL:
					{
						g.setColor(Color.GRAY);
						g.fillRect(x, y, tileSize, tileSize);
						g.setColor(Color.BLACK);
						g.fillRect(x, y + qts, tileSize, hts);
					}
						break;
					case V_WALL:
					{
						g.setColor(Color.GRAY);
						g.fillRect(x, y, tileSize, tileSize);
						g.setColor(Color.BLACK);
						g.fillRect(x + qts, y, hts, tileSize);
					}
						break;
					case DOOR:
					{
						g.setColor(Color.BLUE);
						g.fillRect(x, y, tileSize, tileSize);
					}
						break;
					default:
					{
						g.setColor(new Color(r * 10 + 50, c * 10 + 50, 255));
						g.fillRect(x, y, tileSize, tileSize);
					}
				}
				// Draw tile outline
				g.setColor(Color.BLACK);
				g.drawRect(x, y, tileSize, tileSize);
				
			}
		}
	}
	
}

package acsse.csc2a.file;

import java.io.File;
import java.io.*;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.*;

import acsse.csc2a.model.CrewCombat;
import acsse.csc2a.model.CrewEngineer;
import acsse.csc2a.model.CrewMedic;
import acsse.csc2a.model.CrewMember;
import acsse.csc2a.model.CrewPsychic;
import acsse.csc2a.model.CrewScience;
import acsse.csc2a.model.E_CREW_RANK;
import acsse.csc2a.model.E_TILE_TYPE;
import acsse.csc2a.model.ShipLayout;
import acsse.csc2a.model.CrewEntity;

/**
 * @author Mr A. Maganlal
 */
public class CrewRoster
{
	public static ShipLayout readShipLayout(String layoutFileName)
	{
		ShipLayout layout = null;
		File layoutFile = new File(layoutFileName);
		if (!layoutFile.exists()) return layout;
		System.out.println("Checking file: " + layoutFileName);
		Scanner scLayout = null;
		try
		{
			scLayout = new Scanner(layoutFile);
			String layoutLine = "";
			if (!scLayout.hasNext()) { return layout; }
			layoutLine = scLayout.nextLine();
			StringTokenizer firstLine = new StringTokenizer(layoutLine);
			int rows = Integer.parseInt(firstLine.nextToken());
			int cols = Integer.parseInt(firstLine.nextToken());
			E_TILE_TYPE[][] tiles = new E_TILE_TYPE[rows][cols];
			int row=0;
			while (scLayout.hasNext())
			{
				layoutLine = scLayout.nextLine();
				for (int col = 0; col < layoutLine.length(); col++)
				{
					tiles[row][col]=E_TILE_TYPE.getTileFromChar(layoutLine.charAt(col)); 
				}
				row++;
			}
			layout=new ShipLayout(tiles);
		}
		catch (FileNotFoundException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if (scLayout != null) scLayout.close();
		}

		return layout;
	}

	public static ArrayList<CrewMember> readRoster(String rosterFileName)
	{
		ArrayList<CrewMember> members = new ArrayList<>();
		File roster = new File(rosterFileName);
		if (!roster.exists()) return members;
		System.out.println("Checking file: " + rosterFileName);
		Scanner scRoster = null;
		try
		{
			scRoster = new Scanner(roster);
			String rosterLine = "";
			// \w{6}\s[a-zA-Z]{3}\s\w+\s\d+\s[A-Z]+\s\w+\s\w+
			Pattern crewPattern =
					Pattern.compile("\\w{6}\\s[a-zA-Z]{3}\\s\\w+\\s\\d+\\s[A-Z]+\\s\\w+\\s\\w+");
			Matcher crewMatcher = null;
			//int index = 0;
			if (!scRoster.hasNext()) { return members; }
			
			while (scRoster.hasNext())
			{
				rosterLine = scRoster.nextLine();
				crewMatcher = crewPattern.matcher(rosterLine);
				if (crewMatcher.matches())
				{
					/*if (index >= members.length)
					{
						System.out.println(
								"Resize " + members.length + " -> " + (members.length * 2));
						CrewMember[] tempArray = new CrewMember[members.length * 2];
						System.arraycopy(members, 0, tempArray, 0, members.length);
						members = tempArray;
					}*/
					StringTokenizer memberTokens = new StringTokenizer(rosterLine);
					String ID = memberTokens.nextToken();
					E_CREW_RANK rank = E_CREW_RANK.valueOf(memberTokens.nextToken());
					String surname = memberTokens.nextToken();
					int level = Integer.parseInt(memberTokens.nextToken());
					String type = memberTokens.nextToken();
					String special = memberTokens.nextToken();
					String value = memberTokens.nextToken();
					CrewMember member = null;
					switch (type)
					{
					case "SCIENCE":
					{
						member = new CrewScience(ID, rank, surname, type, special, level, value);
						break;
					}
					case "MEDICAL":
					{
						int heal = Integer.parseInt(value);
						member = new CrewMedic(ID, rank, surname, type, special, level, heal);
						break;
					}
					case "PSYCHIC":
					{
						member = new CrewPsychic(ID, rank, surname, type, special, level, value);
						break;
					}
					case "ENGINEERING":
					{

						int repair = Integer.parseInt(value);
						member = new CrewEngineer(ID, rank, surname, type, special, level, repair);
						break;
					}
					case "COMBAT":
					{
						int damage = Integer.parseInt(value);
						member = new CrewCombat(ID, rank, surname, type, special, level, damage);
						break;
					}
					default:
						break;
					}
					members.add(member);
				}
				else
				{
					System.err.println(rosterLine);
				}
			}
			/*if (index != 0 && index < members.length)
			{
				System.out.println(index + " " + members.length);
				index--;
				CrewMember[] tempArray = new CrewMember[index];
				System.arraycopy(members, 0, tempArray, 0, index);
				members = tempArray;
			}*/
		}
		catch (FileNotFoundException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if (scRoster != null) scRoster.close();
		}

		return members;
	}
	
	public static ArrayList<CrewEntity> readLocations(String fileName, ArrayList<CrewMember> members){
		ArrayList<CrewEntity> entities = new ArrayList<>();
		File locationFile = new File(fileName);
		DataInputStream locationStream = null;
		try{
			FileInputStream fiStream = new FileInputStream(locationFile);
			locationStream = new DataInputStream(new BufferedInputStream(fiStream));
			boolean read = true;
			while(read){
				try{
					String crew_id = locationStream.readUTF();
					int row = locationStream.readInt();
					int col = locationStream.readInt();
					for(CrewMember crew : members){
						if(crew_id.equals(crew.getID())){
							entities.add(new CrewEntity(crew, row, col));
						}
					}
				}catch(EOFException ex){
					//End of file reached
					read = false;
				}
			}
			
		}catch(IOException ex){
			ex.printStackTrace();
		}finally{
			if(locationStream != null){
				try{
					locationStream.close();
				}catch(IOException ex){
					ex.printStackTrace();
				}
			}
		}
		return entities;
	}
}

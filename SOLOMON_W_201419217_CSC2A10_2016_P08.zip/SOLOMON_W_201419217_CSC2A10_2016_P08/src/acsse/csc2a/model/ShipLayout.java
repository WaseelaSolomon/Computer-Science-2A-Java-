package acsse.csc2a.model;

/**
 * @author Mr A. Maganlal
 */
public class ShipLayout implements IDrawable
{
	private E_TILE_TYPE[][] tiles;
	
	//variables for width and height of the ship layout grid
	private int width;
	private int height;
	
	public ShipLayout(E_TILE_TYPE[][] tiles)
	{
		this.tiles = tiles;
	}

	public E_TILE_TYPE getTile(int row, int col)
	{
		return tiles[row][col];
	}

	public int getRows()
	{
		return tiles.length;
	}
	
	public int getColumns()
	{
		return tiles[0].length;
	}

	//getters and setters for the width and height variables
	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * function to accept a visitor to this class
	 * @param visitor: visitor instance
	 */
	@Override
	public void accept(IDrawVisitor visitor) 
	{
		visitor.draw(this);
	}
	
}

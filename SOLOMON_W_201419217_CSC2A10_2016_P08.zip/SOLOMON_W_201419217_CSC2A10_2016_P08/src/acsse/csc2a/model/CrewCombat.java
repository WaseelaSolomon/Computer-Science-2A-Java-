package acsse.csc2a.model;

/**
 * @author Mr A. Maganlal
 */
public class CrewCombat extends CrewMember
{
	private int damage;

	public CrewCombat(String iD, E_CREW_RANK rank, String surname, String type, String special,
			int level, int damage)
	{
		super(iD, rank, surname, type, special, level);
		this.damage = damage;
	}

	@Override
	public String toString()
	{

		return String.format("%s\t%d", super.toString(), damage);
	}

	@Override
	public void interact()
	{
		System.out.format("Damage dealt: %d%n", damage);
	}

	public int getDamage()
	{
		return damage;
	}

	public void setDamage(int damage)
	{
		this.damage = damage;
	}

}

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;

import Game.File.Load;
import Game.Gui.ControlPanel;
import Game.Gui.GamePanel;
import Game.Objects.GameObject;

public class Main {
	
	//variables to create the GUI
	static JFrame f;
	static GamePanel GPanel;
	static ControlPanel CP;

	public static void main(String[] args) 
	{
		//Message box to show information on the game logic
		JOptionPane.showMessageDialog(null, "Navigate the guitar around the room to find the guitar pick. Yes a guitar, everyone knows a mere mortal cannot magically find a misplaced guitar pick!");
		
		//creating the GUI's frame
		f = new JFrame();
		f.setTitle("The 4th Dimension of Lost Picks!");
		JFileChooser chooser = new JFileChooser("data");
		ArrayList<GameObject> objects = null;	//array of game objects
		
		JPanel button = new JPanel();
		
		//restrict the chooser to only accept .lvl files
		chooser.setFileFilter(new FileNameExtensionFilter("Level files","lvl"));
		
		//allow the user to select a level to play
		int result = chooser.showOpenDialog(null);
		if (result == JFileChooser.APPROVE_OPTION)
		{
			File selectedFile = chooser.getSelectedFile();
			objects = Load.readObjects(selectedFile.getAbsolutePath());	//load appropriate level objects
		}
		
		//creating the functionality for the save button
		JButton btnSave = new JButton("Save Your Score and Quit Game");
		btnSave.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				//receive the user's name
				String PlayerName = JOptionPane.showInputDialog("Enter Your Name: ");
				//save user's name and score to the HighScore file
				Load.SaveGame(GamePanel.gametime(), PlayerName);
				JOptionPane.showMessageDialog(null, "Well done on completing this level! Your Score has been saved to the 'HighScores' file in the HighScores directory!");
				System.exit(0);	//exit game once user completes the level
			}
		});
		
		//add save button to panel
		button.add(btnSave);
		f.add(button, BorderLayout.WEST);
		
		//take focus away from the save button
		button.setFocusable(false);
		
		//add the panel containing the game control's information
		CP = new ControlPanel();
		f.add(CP, BorderLayout.EAST);
		
		//take focus away from the game control's information panel
		CP.setFocusable(false);
		
		//add the actual game panel 
		GPanel = new GamePanel();
		f.add(GPanel, BorderLayout.SOUTH);

		//draw objects from file to the panel
		GPanel.drawObjects(objects);

		f.pack();
		
		//set basic frame specifications
		f.setSize(616, 720);
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		
		//ensure the game panel is being focused on
		GPanel.setFocusable(true);
		GPanel.requestFocusInWindow();
	}
}

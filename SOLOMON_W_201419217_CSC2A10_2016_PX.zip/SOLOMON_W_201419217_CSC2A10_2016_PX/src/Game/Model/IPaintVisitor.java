package Game.Model;

import Game.Objects.GameObject;

/**
 * interface used to define the visitor for the paintable classes
 * @author W Solomon
 *
 */
public interface IPaintVisitor 
{
	void paint(GameObject object);
}

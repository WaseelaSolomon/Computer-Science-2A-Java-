package Game.Model;

/**
 * interface used to specify which classes are paintable
 * @author W Solomon
 *
 */
public interface IPaintable 
{
	void accept(IPaintVisitor visitor);
}

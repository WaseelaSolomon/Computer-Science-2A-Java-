package Game.File;

import java.awt.Point;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

import Game.Model_Factory.GameObjectFactory;
import Game.Model_Factory.ObjectFactory;
import Game.Objects.GameObject;

/**
 * 
 * @author W Solomon
 *
 *This class is used to read/write text files, namely reading game objects and saving the game
 */
public class Load 
{
	/**
	 * This function is used to read game objects from a certain file and produce an array of those 
	 * objects
	 * @param FileName: specifies the file to read from
	 * @return: returns the array of objects read from file
	 */
	public static ArrayList<GameObject> readObjects(String FileName)
	{
		//**FACTORY DESIGN PATTERN** 
		ObjectFactory factory = new GameObjectFactory();
		
		//array to store all the objects read from file
		ArrayList<GameObject> obj = new ArrayList<>();
		
		//reading from the file
		File txtin = new File(FileName);
		if(txtin.exists())
		{
			Scanner sc = null;
			try
			{
				sc = new Scanner(txtin);
				
				//variables to store object data from file
				String type;
				Point p = null;
				String[] temp;
				
				while(sc.hasNext())
				{
					//reading into variables from file
					String line = sc.nextLine();
					temp = line.split("\t");
					type = temp[0];
					p = new Point(Integer.parseInt(temp[1]), Integer.parseInt(temp[2]));
					
					//**USING FACTORY DESIGN PATTERN**
					//determine type of object and instantiate each object 
					GameObject gObj = null;
					switch(type)
					{
					case "g":
						gObj = (GameObject) factory.ProduceGoal(p); 
						break;
					case "o":
						gObj = (GameObject) factory.ProduceObstacle(p); 
						break;
						default:
							System.err.println("Type of object not found.");
					}
					obj.add(gObj);	//add objects into the arraylist
				}
			}
			catch(FileNotFoundException ex)
			{
				ex.printStackTrace();
			}
			finally
			{
				if(sc!=null) sc.close();	//close the file
			}
		}
		return obj;	//return the array of objects
	}
	
	/**
	 * This function is used to save the player's score upon game completion to a text file
	 * @param timeElapsed: specifies the time taken to complete the game
	 * @param name: specifies the player's name
	 */
	public static void SaveGame(Float timeElapsed, String name)
	{
		//variables used to write to file
		FileWriter fw = null;
		BufferedWriter bw = null;
		PrintWriter pw = null;	//PrintWriter used to write strings to new file
		
		//writing to file
		try
		{
			//create a file or append the file called HighScores to save to 
			fw = new FileWriter("HighScores/HighScores.txt", true);
		    bw = new BufferedWriter(fw);
			pw = new PrintWriter(bw);
			
			//save player's name and time-score to file
			pw.println("Name: " + name + " - time taken: " + timeElapsed + "s");
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if(pw!=null) pw.close();	//close the file
		}
	}
}

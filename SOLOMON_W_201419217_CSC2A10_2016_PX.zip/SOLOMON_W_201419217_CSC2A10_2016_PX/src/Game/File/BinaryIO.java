package Game.File;
import java.io.*;

/**
 * 
 * @author W Solomon
 *
 *This class will implement functions to read/write binary files
 */
public class BinaryIO 
{
	/**
	 * This function is used to write the controls for the game to a binary file
	 * necessary in case the file is accidentally deleted
	 */
	public static void Write()
	{
		DataOutputStream output = null; 
		try 
		{ 
			//write instructions to a binary file
			output = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("data/data.dat"))); 
			output.writeUTF("Controls: "); 
			output.writeUTF("Move Up: Arrow_UP"); 
			output.writeUTF("Move Down: Arrow_DOWN"); 
			output.writeUTF("Move Left: Arrow_LEFT"); 
			output.writeUTF("Move Right: Arrow_RIGHT"); 
		}
		catch(IOException ex)
		{
			ex.printStackTrace(); 
		}
		finally
		{ 
			if(output != null)
			{ 
				try
				{ 
					output.close(); //close the file
				} 
				catch(IOException ex)
				{ 
					ex.printStackTrace(); 
				} 
			} 
		}
	}
	
	/**
	 * This function is used to read the game instructions from a binary file
	 * @return: a string array of the game's controls/instructions 
	 */
	public static String[] Read()
	{
		//array to store the game controls/instructions
		String[] controls = new String[5];
		
		DataInputStream input = null;
		try
		{
			//read the controls/instructions from the binary file
			input = new DataInputStream(new FileInputStream("data/data.dat"));
			controls[0] = input.readUTF();
			controls[1] = input.readUTF();
			controls[2] = input.readUTF();
			controls[3] = input.readUTF();
			controls[4] = input.readUTF();
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if(input != null)
			{
				try
				{
					input.close();	//close the file
				}
				catch(IOException ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return controls;	//return the controls/instructions
	}
}

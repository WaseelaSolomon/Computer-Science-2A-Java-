package Game.Gui;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

import Game.Model.IPaintVisitor;
import Game.Objects.GameObject;
import Game.Objects.Goal;
import Game.Objects.Obstacle;
import Game.Objects.Player;

/**
 * class to draw each object
 * @author W Solomon
 *
 */
public class PaintGraphicsVisitor implements IPaintVisitor
{
	//variables
	private Graphics g;
	private static int tileSize = 50;
	
	//image variables
	private Image wall, player, goal;
	
	/**
	 * function to set the graphics and images
	 * @param g: specifies the graphics instance
	 */
	public void setGraphics(Graphics g) {
		this.g = g;	//set graphics
		
		//set all needed images
		ImageIcon img = new ImageIcon("data/wall.png");
		wall = img.getImage();
		
		img = new ImageIcon("data/player.png");
		player = img.getImage();
		
		img = new ImageIcon("data/pick.png");
		goal = img.getImage();
	}
	
	/**
	 * function to paint each object 
	 * @param object: specifies the object to be painted
	 */
	@Override
	public void paint(GameObject object) 
	{
		//check which object is being passed and paint the object as an image
		if(object instanceof Player)
		{
			g.drawImage(player, object.getLocation().x * tileSize, object.getLocation().y * tileSize, null);
		}else if(object instanceof Goal)
		{
			g.drawImage(goal, object.getLocation().x * tileSize, object.getLocation().y * tileSize, null);
		}else if(object instanceof Obstacle)
		{
			g.drawImage(wall, object.getLocation().x * tileSize, object.getLocation().y * tileSize, null);
		}	
	}

}

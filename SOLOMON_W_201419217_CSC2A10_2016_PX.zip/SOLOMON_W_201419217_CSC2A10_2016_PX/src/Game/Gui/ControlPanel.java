package Game.Gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JPanel;

import Game.File.BinaryIO;

@SuppressWarnings("serial")
/**
 * Class used to draw the game's controls/instructions onto a panel
 * @author W Solomon
 *
 */
public class ControlPanel extends JPanel 
{
	//array to store game controls 
	String[] controls = new String[5];
	
	/**
	 * constructor that initializes the panel specifics
	 */
	public ControlPanel()
	{
		//initialize the panel specifics
		Dimension d = new Dimension(250, 50);
		this.setSize(d);
		this.setPreferredSize(d);
	}
	
	/**
	 * function to draw the controls/instructions onto a panel
	 */
	@Override
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		//create the file in case it doesn't exist
		BinaryIO.Write();
		
		//read the instructions from file
		controls = BinaryIO.Read();
		
		//draw instructions onto the panel
		g.setColor(Color.black);
		g.fillRect(0, 0, 150, 80);
		g.setFont(new Font("Serif", Font.ROMAN_BASELINE, 12));
		g.setColor(Color.white);
		g.drawString(controls[0], 0, 12);
		g.drawString(controls[1], 0, 24);
		g.drawString(controls[2], 0, 36);
		g.drawString(controls[3], 0, 48);
		g.drawString(controls[4], 0, 60);
	}
}

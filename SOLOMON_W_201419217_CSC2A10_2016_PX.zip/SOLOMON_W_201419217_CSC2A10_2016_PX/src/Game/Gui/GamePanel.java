package Game.Gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

import Game.Objects.GameObject;
import Game.Objects.Goal;
import Game.Objects.Obstacle;
import Game.Objects.Player;

@SuppressWarnings("serial")
/**
 * Class used to draw the game world onto a panel as well as create the game functionality
 * @author W Solomon
 *
 */
public class GamePanel extends JPanel implements ActionListener, KeyListener
{
	//variables to keep track of the game time
	static long gameStartTime = System.currentTimeMillis();
	public static Float timetaken;
	
	//variables for the game world
	ArrayList<GameObject> objs = null;
	String[][] arry = new String[12][12];
	Player player = new Player(new Point(1, 1));
	private static int	tileSize = 50;
	private static int	x, y;
	int px = 1, py = 1, velx = 0, vely = 0;
	private Image floor;
	
	//variable to refresh the panel
	Timer timer = new Timer(25, this);
	
	//variable to check for game completion
	boolean win = false;
	
	//**VISITOR DESIGN PATTERN**
	private PaintGraphicsVisitor visitor = new PaintGraphicsVisitor();
	
	/**
	 * constructor to initialize necessary variables
	 */
	public GamePanel()
	{
		//start the refresh timer
		timer.start();
		
		//add key listeners to this panel
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		
		//set the panel specifications
		Dimension d = new Dimension(12 * tileSize, 12 * tileSize);
		this.setSize(d);
		this.setPreferredSize(d);
		
		//set the image for the floor tiles in the game
		ImageIcon img = new ImageIcon("data/floor.png");
		floor = img.getImage();
	}
	
	/**
	 * function used to populate a string array with the game world's layout with empty tiles
	 */
	public void initarray()
	{
		for(int c = 0; c < 12; c++)
		{
			for(int r = 0; r < 12; r++)
			{
				arry[r][c] = "b";	//initialize the world with empty tiles
			}
		}
	}
	
	/**
	 * function used to populate a string array with the game world's layout with appropriate
	 * objects
	 */
	public void arraystuff()
	{
		initarray();
		for(int c = 0; c < 12; c++)
		{
			for(int r = 0; r < 12; r++)
			{
				for(GameObject o : objs)
				{
					if((r == o.getLocation().getX()) & (c == o.getLocation().getY()))
					{
						if(o instanceof Player)
						{
							arry[r][c] = "p";	//indicates a player object
						}else if(o instanceof Goal)
						{
							arry[r][c] = "g";	//indicates a goal object
						}else if(o instanceof Obstacle)
						{
							arry[r][c] = "o";	//indicates an obstacle object
						}
					}
				}
			}
		}
		
	}
	
	/**
	 * function to calculate the time taken to complete the game
	 * @return: time taken to complete the game
	 */
	public static Float gametime()
	{
		//convert time taken from milliseconds to seconds and return result
		timetaken = (System.currentTimeMillis() - gameStartTime) / 1000F;
		return timetaken;
	}
	
	/**
	 * function to draw the game's win screen
	 * @param g: specifies the graphics instance
	 */
	public void winScreen(Graphics g)
	{
		//draw the image for the win screen onto the panel
		ImageIcon img = new ImageIcon("data/screen.png");
		Image winScreen = img.getImage();
		g.drawImage(winScreen, 0, 0, null);
	}
	
	/**
	 * function to draw the game objects onto the panel
	 */
	@Override
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		//**USING VISITOR DESIGN PATTERN**
		visitor.setGraphics(g);
		
		if(!win)	//check if the player has won the game yet
		{
			g.clearRect(0, 0, getWidth(), getHeight());
			for (int r = 0; r < 12; r++)
			{
				for (int c = 0; c < 12; c++)
				{
					x = r * tileSize;
					y = c * tileSize;
					
					g.drawImage(floor, x, y, null);	//draw the floor tiles
				}
			}
			
			//drawing each game object onto the panel
			if(objs!=null)
			{
				//add the player to the panel
				objs.add(player);
				for(GameObject o : objs)
				{
					o.accept(visitor);	//using visitor design pattern to paint the player
				}
			}
			arraystuff(); //getting the layout for the game
		}
		
		if(win) //check if the player has won the game yet
		{
			winScreen(g);	//display the game's win screen
		}
	}
	
	/**
	 * function used to constantly repaint the objects onto the panel
	 * @param objs: specifies the game objects to repaint
	 */
	public void drawObjects(ArrayList<GameObject> objs){
		this.objs = objs;
		repaint();
	}

	@Override
	public void keyTyped(KeyEvent e) 
	{
			
	}

	/**
	 * function to perform an action when a certain key is pressed
	 * @param: specifies the key that was pressed
	 */
	@Override
	public void keyPressed(KeyEvent e) {
		int keycode = e.getKeyCode();	//get the keycode of the key pressed
		
		//check which key was pressed
		if(keycode == KeyEvent.VK_LEFT)
		{
			//move the player one cell to the left
			if(!(arry[(player.getLocation().x - 1)][(player.getLocation().y)] == "o"))
			{
				player.setLocation(new Point(player.getLocation().x - 1, player.getLocation().y));
			}
			
			//check if the player has reached the goal
			if(arry[(player.getLocation().x)][(player.getLocation().y)] == "g")
			{
				win = true;
			}
		}
		else if(keycode == KeyEvent.VK_UP)
		{
			//move the player one cell up
			if(!(arry[(player.getLocation().x)][(player.getLocation().y - 1)] == "o"))
			{
				player.setLocation(new Point(player.getLocation().x, player.getLocation().y - 1));
			}
			
			//check if the player has reached the goal
			if(arry[(player.getLocation().x)][(player.getLocation().y)] == "g")
			{
				win = true;
			}
			
		}
		else if(keycode == KeyEvent.VK_RIGHT)
		{
			//move the player one cell to the right
			if(!(arry[(player.getLocation().x + 1)][(player.getLocation().y)] == "o"))
			{
				player.setLocation(new Point(player.getLocation().x + 1, player.getLocation().y));
			}
			
			//check if the player has reached the goal
			if(arry[(player.getLocation().x)][(player.getLocation().y)] == "g")
			{
				win = true;
			}
		}
		else if(keycode == KeyEvent.VK_DOWN)
		{
			//move the player one cell down
			if(!(arry[(player.getLocation().x)][(player.getLocation().y + 1)] == "o"))
			{
				player.setLocation(new Point(player.getLocation().x, player.getLocation().y + 1));
			}
			
			//check if the player has reached the goal
			if(arry[(player.getLocation().x)][(player.getLocation().y)] == "g")
			{
				win = true;
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
	}

	/**
	 * function to repaint the panel
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		repaint();
	}
	
}

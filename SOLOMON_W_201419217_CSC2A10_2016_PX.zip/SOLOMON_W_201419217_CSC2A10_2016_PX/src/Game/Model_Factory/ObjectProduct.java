package Game.Model_Factory;

/**
 * class  to determine which objects can be produced by our factory
 * @author W Solomon
 *
 */
public interface ObjectProduct {

}

package Game.Model_Factory;

import java.awt.Point;

import Game.Objects.Goal;
import Game.Objects.Obstacle;
import Game.Objects.Player;

/**
 * class to implement methods from ObjectFactory - create object of a certain type
 * @author W Solomon
 *
 */
public class GameObjectFactory extends ObjectFactory 
{

	@Override
	public ObjectProduct ProducePlayer(Point p) 
	{
		return new Player(p);
	}

	@Override
	public ObjectProduct ProduceGoal(Point p) 
	{
		return new Goal(p);
	}

	@Override
	public ObjectProduct ProduceObstacle(Point p) 
	{
		return new Obstacle(p);
	}

}

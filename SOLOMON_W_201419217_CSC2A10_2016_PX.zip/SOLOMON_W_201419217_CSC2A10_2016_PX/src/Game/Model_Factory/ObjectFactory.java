package Game.Model_Factory;

import java.awt.Point;

/**
 * class define the methods for creating different objects
 * @author W Solomon
 *
 */
public abstract class ObjectFactory 
{
	public abstract ObjectProduct ProducePlayer(Point p);
	public abstract ObjectProduct ProduceGoal(Point p);
	public abstract ObjectProduct ProduceObstacle(Point p);
}

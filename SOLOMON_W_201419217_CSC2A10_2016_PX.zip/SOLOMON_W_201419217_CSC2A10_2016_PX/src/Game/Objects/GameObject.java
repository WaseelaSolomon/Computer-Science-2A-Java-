package Game.Objects;

import java.awt.Point;

import Game.Model.IPaintable;

/**
 * abstract base class for all game objects
 * @author W Solomon
 *
 */
public abstract class GameObject implements IPaintable
{
	//variables
	protected Point location;

	/**
	 * constructor to initialize class variable
	 * @param location: specifies the objects location
	 */
	public GameObject(Point location) {
		this.location = location;
	}

	//getter for location variable
	public Point getLocation() {
		return location;
	}

	//setter for location variable
	public void setLocation(Point location) {
		this.location = location;
	}
	
}

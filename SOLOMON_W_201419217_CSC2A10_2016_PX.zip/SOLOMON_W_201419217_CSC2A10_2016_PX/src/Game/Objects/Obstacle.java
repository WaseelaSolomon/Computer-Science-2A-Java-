package Game.Objects;

import java.awt.Point;

import Game.Model.IPaintVisitor;
import Game.Model_Factory.ObjectProduct;

/**
 * class for the Obstacle game object
 * @author W Solomon
 *
 */
public class Obstacle extends GameObject implements ObjectProduct
{
	/**
	 * constructor to initialize the location variable
	 * @param location: specifies the location of the object
	 */
	public Obstacle(Point location) 
	{
		super(location);
	}
	
	//**VISITOR DESIGN PATTERN**
	/**
	 * function to mark this class as paintable
	 */
	@Override
	public void accept(IPaintVisitor visitor) 
	{
		visitor.paint(this);
	}

}

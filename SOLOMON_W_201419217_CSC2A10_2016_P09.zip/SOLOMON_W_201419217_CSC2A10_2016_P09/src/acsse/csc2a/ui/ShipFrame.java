package acsse.csc2a.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileFilter;

import acsse.csc2a.file.CrewRoster;
import acsse.csc2a.model.CrewMember;
import acsse.csc2a.model.CrewEntity;

/**
 * @author Mr A. Maganlal
 */
public class ShipFrame extends JFrame
{
	private JButton			btnOpen;
	private JButton			btnSave;
	private JTextArea		txtRoster;
	private JFileChooser	chooser;
	private ShipPanel pnlShip;
	

	public ShipFrame()
	{
		//**SINGLETON DESIGN PATTERN**
		final CrewRoster reader = CrewRoster.getInstance();	//variable used to get an instance of CrewRoster
		
		JFileChooser chooser = new JFileChooser("data");

		setTitle("Ship GUI");
		txtRoster = new JTextArea();
		add(txtRoster, BorderLayout.EAST);
		
		pnlShip = new ShipPanel(CrewRoster.readShipLayout("data/SSInvictus.lvl"));
		add(pnlShip, BorderLayout.CENTER);

		JPanel pnlButtons = new JPanel();

		btnOpen = new JButton("Open roster file");
		btnOpen.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e)
			{
				chooser.setDialogTitle("Select Roster");
				int result = chooser.showOpenDialog(ShipFrame.this);
				if (result == JFileChooser.APPROVE_OPTION)
				{
					File selectedFile = chooser.getSelectedFile();
					
					//**SINGLETON DESIGN PATTERN**
					//using single instance of CrewRoster class to read from file and populate member array
					ArrayList<CrewMember> members = reader.readRoster(selectedFile.getAbsolutePath());
					
					for (CrewMember member : members)
					{
						txtRoster.append(member.toString() + "\n");
					}
					pack();
					//Now get the location of the crew members
					chooser.setDialogTitle("Select Locations");
					result = chooser.showOpenDialog(ShipFrame.this);
					if (result == JFileChooser.APPROVE_OPTION)
					{						
						selectedFile = chooser.getSelectedFile();						
						ArrayList<CrewEntity> entities = CrewRoster.readLocations(selectedFile.getAbsolutePath(), members);
						pnlShip.drawCrewEntities(entities);	
					}
				}
			}
		});

		btnSave = new JButton("Save text to file");
		btnSave.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				int result = chooser.showSaveDialog(ShipFrame.this);
				if (result == JFileChooser.APPROVE_OPTION)
				{
					File selectedFile = chooser.getSelectedFile();
					String text = txtRoster.getText();
					PrintWriter txtout = null;
					try
					{
						txtout = new PrintWriter(selectedFile);
						txtout.print(text);
						txtout.flush();
					}
					catch (FileNotFoundException fnfe)
					{
						fnfe.printStackTrace();
					}
					finally
					{
						if (txtout != null)
						{
							txtout.close();
						}
					}
				}
			}
		});

		pnlButtons.add(btnOpen);
		pnlButtons.add(btnSave);
		add(pnlButtons, BorderLayout.WEST);

		pack();
	}
}

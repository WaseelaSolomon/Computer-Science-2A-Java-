package acsse.csc2a.model;

/**
 * 
 * @author Solomon W
 * this is the visitor interface used to define the visitor for the drawable classes
 */
public interface IDrawVisitor 
{
	//draw methods
	void draw(CrewEntity entity);
	void draw(ShipLayout layout);
}

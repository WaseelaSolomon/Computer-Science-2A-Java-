package acsse.csc2a.model;

/**
 * @author Mr A. Maganlal
 */
public abstract class CrewMember
{
	private final String	ID;
	private E_CREW_RANK		rank;
	private String			surname;
	private String			type;
	private String			special;
	private int				level;

	public CrewMember(String iD, E_CREW_RANK rank, String surname, String type, String special,
			int level)
	{
		this.ID = iD;
		setRank(rank);
		setSurname(surname);
		setType(type);
		setSpecial(special);
		setLevel(level);
	}

	public abstract void interact();

	@Override
	public String toString()
	{
		return String.format("%s\t%s\t%s\t%d\t%s\t%s", ID, rank, surname, level, type, special);
	}

	public E_CREW_RANK getRank()
	{
		return rank;
	}

	public void setRank(E_CREW_RANK rank)
	{
		this.rank = rank;
	}

	public String getSurname()
	{
		return surname;
	}

	public void setSurname(String surname)
	{
		this.surname = surname;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getSpecial()
	{
		return special;
	}

	public void setSpecial(String special)
	{
		this.special = special;
	}

	public int getLevel()
	{
		return level;
	}

	public void setLevel(int level)
	{
		this.level = level;
	}

	public String getID()
	{
		return ID;
	}

}

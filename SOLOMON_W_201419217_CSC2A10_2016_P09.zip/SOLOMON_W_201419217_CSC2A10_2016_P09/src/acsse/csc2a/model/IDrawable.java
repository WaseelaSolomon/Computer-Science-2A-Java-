package acsse.csc2a.model;

/**
 * 
 * @author Solomon W
 * this is the IDrawable interface used to specify which classes are drawable
 */
public interface IDrawable 
{
	void accept(IDrawVisitor visitor);	//accept method
}

package acsse.csc2a.model;

/*
 * @author BR Greaves
 */
public class CrewEntity implements IDrawable
{
	private CrewMember crewMember = null; //Read-only *
	private int row = 0;
	private int col = 0;
	
	public CrewEntity(CrewMember crewMember, int row, int col){
		this.crewMember = crewMember;
		this.row = row;
		this.col = col;
	}

	public CrewMember getCrewMember() {
		return crewMember;
	}
	//* No setCrewMember()

	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getCol() {
		return col;
	}
	public void setCol(int col) {
		this.col = col;
	}

	/**
	 * function to accept a visitor to this class
	 * @param visitor: visitor instance
	 */
	@Override
	public void accept(IDrawVisitor visitor) 
	{
		visitor.draw(this);
	}	
}

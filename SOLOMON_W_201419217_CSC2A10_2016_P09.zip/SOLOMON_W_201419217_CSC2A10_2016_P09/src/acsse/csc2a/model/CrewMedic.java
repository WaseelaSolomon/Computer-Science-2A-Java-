package acsse.csc2a.model;

import acsse.csc2a.model_factory.EntityProduct;

/**
 * @author Mr A. Maganlal
 */
public class CrewMedic extends CrewMember implements EntityProduct
{
	private int heal;

	public CrewMedic(String iD, E_CREW_RANK rank, String surname, String type, String special,
			int level, int heal)
	{
		super(iD, rank, surname, type, special, level);
		this.heal = heal;
	}

	@Override
	public String toString()
	{

		return String.format("%s\t%d", super.toString(), heal);
	}

	@Override
	public void interact()
	{
		System.out.format("Healing amount: %d%n", heal);
	}

	public int getHeal()
	{
		return heal;
	}

	public void setHeal(int heal)
	{
		this.heal = heal;
	}

}

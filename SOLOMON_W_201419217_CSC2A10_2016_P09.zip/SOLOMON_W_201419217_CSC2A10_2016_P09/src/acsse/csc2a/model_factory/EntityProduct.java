package acsse.csc2a.model_factory;

/**
 * 
 * @author Solomon W
 * This is the interface that will serve as a maker to determine which objects can be produced 
 */
public interface EntityProduct 
{

}

package acsse.csc2a.model_factory;

import acsse.csc2a.model.E_CREW_RANK;

/**
 * 
 * @author Solomon W
 * Abstract Factory class to be used for instantiating certain objects
 */
public abstract class EntityFactory 
{
	//abstract method for creating the different objects of the CrewMember subclasses
	public abstract EntityProduct ProduceCrewPsychic(String ID, E_CREW_RANK rank, String surname, String type, String special, int level, String influence);
	public abstract EntityProduct ProduceCrewScience(String ID, E_CREW_RANK rank, String surname, String type, String special, int level, String enhancement);
	public abstract EntityProduct ProduceCrewCombat(String ID, E_CREW_RANK rank, String surname, String type, String special, int level, int damage);
	public abstract EntityProduct ProduceCrewEngineer(String ID, E_CREW_RANK rank, String surname, String type, String special, int level, int repair);
	public abstract EntityProduct ProduceCrewMedic(String ID, E_CREW_RANK rank, String surname, String type, String special, int level, int heal);
}

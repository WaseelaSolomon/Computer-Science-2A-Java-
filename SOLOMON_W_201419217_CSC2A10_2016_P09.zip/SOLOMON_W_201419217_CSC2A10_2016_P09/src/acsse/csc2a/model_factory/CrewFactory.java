package acsse.csc2a.model_factory;

import acsse.csc2a.model.CrewCombat;
import acsse.csc2a.model.CrewEngineer;
import acsse.csc2a.model.CrewMedic;
import acsse.csc2a.model.CrewPsychic;
import acsse.csc2a.model.CrewScience;
import acsse.csc2a.model.E_CREW_RANK;

/**
 * 
 * @author Solomon W
 * This is the factory class that will implement each of the five methods from the abstract base class called EntityFactory.
 */
public class CrewFactory extends EntityFactory {

	/**
	 * function to create a CrewPsychic object
	 * @return: a CrewPsychic instance
	 */
	@Override
	public EntityProduct ProduceCrewPsychic(String ID, E_CREW_RANK rank, String surname, String type, String special, int level, String influence) 
	{
		return new CrewPsychic(ID, rank, surname, type, special, level, influence);
	}
	
	/**
	 * function to create a CrewScience object
	 * @return: a CrewScience instance
	 */
	@Override
	public EntityProduct ProduceCrewScience(String ID, E_CREW_RANK rank, String surname, String type, String special, int level, String enhancement) 
	{
		return new CrewScience(ID, rank, surname, type, special, level, enhancement);
	}

	/**
	 * function to create a CrewCombat object
	 * @return: a CrewCombat instance
	 */
	@Override
	public EntityProduct ProduceCrewCombat(String ID, E_CREW_RANK rank, String surname, String type, String special, int level, int damage) 
	{	
		return new CrewCombat(ID, rank, surname, type, special, level, damage);
	}

	/**
	 * function to create a CrewEngineer object
	 * @return: a CrewEngineer instance
	 */
	@Override
	public EntityProduct ProduceCrewEngineer(String ID, E_CREW_RANK rank, String surname, String type, String special, int level, int repair) 
	{
		return new CrewEngineer(ID, rank, surname, type, special, level, repair);
	}

	/**
	 * function to create a CrewMedic object
	 * @return: a CrewMedic instance
	 */
	@Override
	public EntityProduct ProduceCrewMedic(String ID, E_CREW_RANK rank, String surname, String type, String special, int level, int heal) 
	{
		return new CrewMedic(ID, rank, surname, type, special, level, heal);
	}

}

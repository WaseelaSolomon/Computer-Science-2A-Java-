import javax.swing.JFrame;

import acsse.csc2a.ui.ShipFrame;
/**
 * @author Mr A. Maganlal
 */
public class Main
{
	public static void main(String[] args)
	{
		ShipFrame frame = new ShipFrame();
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
